# Appia Nansen Integration

**Alguns pontos do projeto**
- desenvolvido em python
- independência de módulos
- escalável
